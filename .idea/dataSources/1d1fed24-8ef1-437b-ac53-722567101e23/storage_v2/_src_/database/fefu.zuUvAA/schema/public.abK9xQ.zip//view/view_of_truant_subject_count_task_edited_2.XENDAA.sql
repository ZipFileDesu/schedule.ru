create view view_of_truant_subject_count_task_edited_№2("Name", truant_cnt) as
SELECT t3."Name",
       sum(
               CASE
                   WHEN t1."Visited" = false THEN 1
                   ELSE 0
                   END) AS truant_cnt
FROM "Journal" t1
         JOIN "Schedule" t2 ON t1."Schedule_id" = t2.id
         JOIN "Subjects" t3 ON t2."Lesson_id" = t3.id
WHERE (t1."Student_id" IN (SELECT t1_1.student_id
                           FROM (SELECT concat(t1_2."First_Name", ' ', t1_2."Last_Name", ' ',
                                               t1_2."Middle_Name") AS concat,
                                        t1_2.id                    AS student_id,
                                        t4."Name"                  AS subject_name,
                                        CASE
                                            WHEN (count(t2_1."Visited") FILTER (WHERE t2_1."Visited" = true)::double precision /
                                                  count(t2_1."Visited")::double precision) < 0.5::double precision
                                                THEN 'Прогульщик'::text
                                            WHEN (count(t2_1."Visited") FILTER (WHERE t2_1."Visited" = true)::double precision /
                                                  count(t2_1."Visited")::double precision) = 0.5::double precision
                                                THEN '50:50'::text
                                            ELSE NULL::text
                                            END                    AS is_truant
                                 FROM "Students" t1_2
                                          JOIN "Journal" t2_1 ON t1_2.id = t2_1."Student_id"
                                          JOIN "Schedule" t3_1 ON t2_1."Schedule_id" = t3_1.id
                                          JOIN "Subjects" t4 ON t3_1."Lesson_id" = t4.id
                                 GROUP BY (concat(t1_2."First_Name", ' ', t1_2."Last_Name", ' ', t1_2."Middle_Name")),
                                          t1_2.id, t4."Name"
                                 HAVING (count(t2_1."Visited") FILTER (WHERE t2_1."Visited" = true)::double precision /
                                         count(t2_1."Visited")::double precision) <= 0.5::double precision
                                 ORDER BY (concat(t1_2."First_Name", ' ', t1_2."Last_Name", ' ',
                                                  t1_2."Middle_Name"))) t1_1))
GROUP BY t3."Name"
ORDER BY (sum(
        CASE
            WHEN t1."Visited" = false THEN 1
            ELSE 0
            END)) DESC;

alter table view_of_truant_subject_count_task_edited_№2
    owner to postgres;

