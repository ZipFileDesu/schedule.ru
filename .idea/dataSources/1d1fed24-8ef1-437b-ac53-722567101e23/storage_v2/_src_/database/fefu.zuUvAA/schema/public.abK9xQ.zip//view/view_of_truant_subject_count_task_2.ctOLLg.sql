create view view_of_truant_subject_count_task_№2("Name", visits_count, truant_count) as
SELECT t3."Name",
       count(t1."Visited") FILTER (WHERE t1."Visited" = true)  AS visits_count,
       count(t1."Visited") FILTER (WHERE t1."Visited" = false) AS truant_count
FROM "Journal" t1
         JOIN "Schedule" t2 ON t1."Schedule_id" = t2.id
         JOIN "Subjects" t3 ON t2."Lesson_id" = t3.id
GROUP BY t3."Name"
ORDER BY (count(t1."Visited") FILTER (WHERE t1."Visited" = false)) DESC;

alter table view_of_truant_subject_count_task_№2
    owner to postgres;

