create view full_schedule("Date", time, group_name, subject_name, classroom, professor_name) as
SELECT t1."Date",
       concat(t4."Start_time", '-', t4."End_time")                         AS "time",
       t2."Name"                                                           AS group_name,
       t3."Name"                                                           AS subject_name,
       t5."Name"                                                           AS classroom,
       concat(t6."First_Name", ' ', t6."Last_Name", ' ', t6."Middle_Name") AS professor_name
FROM "Schedule" t1
         JOIN "Groups" t2 ON t1."Group_id" = t2.id
         JOIN "Subjects" t3 ON t1."Lesson_id" = t3.id
         JOIN "Pairs" t4 ON t1."Pair_id" = t4.id
         JOIN "Classrooms" t5 ON t1."Classroom_id" = t5.id
         JOIN "Professors" t6 ON t1."Professor_id" = t6.id;

alter table full_schedule
    owner to postgres;

