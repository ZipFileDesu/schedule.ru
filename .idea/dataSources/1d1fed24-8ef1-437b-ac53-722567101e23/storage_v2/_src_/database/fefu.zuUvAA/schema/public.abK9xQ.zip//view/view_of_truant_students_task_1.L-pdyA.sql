create view view_of_truant_students_task_№1(concat, subject_name, is_truant) as
SELECT concat(t1."First_Name", ' ', t1."Last_Name", ' ', t1."Middle_Name") AS concat,
       t4."Name"                                                           AS subject_name,
       CASE
           WHEN (count(t2."Visited") FILTER (WHERE t2."Visited" = true)::double precision /
                 count(t2."Visited")::double precision) > 0.5::double precision THEN 'Прилежный студент'::text
           WHEN (count(t2."Visited") FILTER (WHERE t2."Visited" = true)::double precision /
                 count(t2."Visited")::double precision) = 0.5::double precision THEN '50:50'::text
           ELSE 'Злостный прогульщик'::text
           END                                                             AS is_truant
FROM "Students" t1
         JOIN "Journal" t2 ON t1.id = t2."Student_id"
         JOIN "Schedule" t3 ON t2."Schedule_id" = t3.id
         JOIN "Subjects" t4 ON t3."Lesson_id" = t4.id
GROUP BY (concat(t1."First_Name", ' ', t1."Last_Name", ' ', t1."Middle_Name")), t4."Name"
ORDER BY (concat(t1."First_Name", ' ', t1."Last_Name", ' ', t1."Middle_Name"));

alter table view_of_truant_students_task_№1
    owner to postgres;

