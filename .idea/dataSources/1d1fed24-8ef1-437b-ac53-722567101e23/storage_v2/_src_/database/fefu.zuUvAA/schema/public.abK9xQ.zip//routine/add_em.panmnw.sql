create function add_em(integer, integer) returns integer
    language sql
as
$$
SELECT $1 + $2;
$$;

alter function add_em(integer, integer) owner to postgres;

