create view view_of_median_marks_and_rnd_student_task_№4("Name", median, student) as
SELECT DISTINCT ON (t4."Name") t4."Name",
                               median(t1.mark::numeric)                                            AS median,
                               concat(t2."First_Name", ' ', t2."Last_Name", ' ', t2."Middle_Name") AS student
FROM "Marks" t1
         JOIN "Students" t2 ON t1.student_id = t2.id
         JOIN "Tasks" t3 ON t1.task_id = t3.id
         JOIN "Subjects" t4 ON t3.subject_id = t4.id
GROUP BY t4."Name", (concat(t2."First_Name", ' ', t2."Last_Name", ' ', t2."Middle_Name"))
ORDER BY t4."Name";

alter table view_of_median_marks_and_rnd_student_task_№4
    owner to postgres;

