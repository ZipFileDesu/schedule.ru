create view view_of_truant_students(concat, is_truant) as
SELECT concat(t1."First_Name", ' ', t1."Last_Name", ' ', t1."Middle_Name") AS concat,
       CASE
           WHEN (count(t2."Visited") FILTER (WHERE t2."Visited" = true)::double precision /
                 count(t2."Visited")::double precision) > 0.5::double precision THEN 'Не злостный прогульщик'::text
           ELSE 'Злостный прогульщик'::text
           END                                                             AS is_truant
FROM "Students" t1
         JOIN "Journal" t2 ON t1.id = t2."Student_id"
GROUP BY (concat(t1."First_Name", ' ', t1."Last_Name", ' ', t1."Middle_Name"));

alter table view_of_truant_students
    owner to postgres;

