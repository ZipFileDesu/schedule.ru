create function minus(integer, integer) returns integer
    language sql
as
$$
SELECT $1 - $2
$$;

alter function minus(integer, integer) owner to postgres;

