create view view_of_excellent_students_task_№3(student_name, avg_mark) as
SELECT concat(t2."First_Name", ' ', t2."Last_Name", ' ', t2."Middle_Name") AS student_name,
       CASE
           WHEN (sum(
                         CASE
                             WHEN t1.mark = 5 THEN 1
                             ELSE 0
                             END)::double precision / count(t1.mark)::double precision) >= 0.75::double precision
               THEN concat('Отличник: ', sum(t1.mark)::double precision / count(t1.mark)::double precision)
           ELSE NULL::text
           END                                                             AS avg_mark
FROM "Marks" t1
         JOIN "Students" t2 ON t1.student_id = t2.id
WHERE NOT (t1.student_id IN (SELECT DISTINCT t3.id
                             FROM "Students" t3
                                      JOIN "Marks" t4 ON t4.student_id = t3.id
                             WHERE t4.mark = 3))
GROUP BY (concat(t2."First_Name", ' ', t2."Last_Name", ' ', t2."Middle_Name"))
HAVING CASE
           WHEN (sum(
                         CASE
                             WHEN t1.mark = 5 THEN 1
                             ELSE 0
                             END)::double precision / count(t1.mark)::double precision) >= 0.75::double precision
               THEN concat('Отличник: ', sum(t1.mark)::double precision / count(t1.mark)::double precision)
           ELSE NULL::text
           END IS NOT NULL;

alter table view_of_excellent_students_task_№3
    owner to postgres;

