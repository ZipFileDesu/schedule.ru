create function new_group() returns trigger
    language plpgsql
as
$$
DECLARE
		new_id integer;
		new_name varchar(255);
  BEGIN
        IF NEW."group_id" IS NULL THEN
			new_id := ((SELECT "id" FROM "task_triggers"."groups" ORDER BY "id" DESC LIMIT 1) + 1);
			new_name := (SELECT "name" FROM "task_triggers"."groups" ORDER BY "name" LIMIT 1);
			raise notice 'Value: %', new_id;
			raise notice 'Value: %', new_name;
            INSERT INTO "task_triggers"."groups" ("name") VALUES(concat(new_name, new_id));
      		NEW."group_id" := new_id;
        END IF;
    RETURN NEW;
  END;

$$;

alter function new_group() owner to postgres;

