create view attendance_log(student_name, date, time, lesson_name, "case") as
SELECT concat(t2."First_Name", ' ', t2."Last_Name", ' ', t2."Middle_Name") AS student_name,
       t3."Date"                                                           AS date,
       concat(t5."Start_time", '-', t5."End_time")                         AS "time",
       t4."Name"                                                           AS lesson_name,
       CASE
           WHEN t1."Visited" = true THEN '+'::text
           ELSE '-'::text
           END                                                             AS "case"
FROM "Journal" t1
         JOIN "Students" t2 ON t1."Student_id" = t2.id
         JOIN "Schedule" t3 ON t1."Schedule_id" = t3.id
         JOIN "Subjects" t4 ON t3."Lesson_id" = t4.id
         JOIN "Pairs" t5 ON t3."Pair_id" = t5.id;

alter table attendance_log
    owner to postgres;

